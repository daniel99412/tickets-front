export class AppSettings {
    public static readonly API = 'http://52.14.132.150:3800/api/v1';
    public static readonly SOCKETURL = "http://52.14.132.150:3800";
   
}